package com.easyvictory.mods;

import android.content.Context;
import android.content.SharedPreferences;

/** Autoplay configuration has its own store, separate from login/UI reset. */
final class AutoplaySettings {
    private AutoplaySettings() {}

    static SharedPreferences store(Context context) {
        return context.getApplicationContext().getSharedPreferences("ev_autoplay", Context.MODE_PRIVATE);
    }

    static int lastMode(Context context) {
        return Math.max(1, Math.min(3, store(context).getInt("last_mode", 1)));
    }

    static void rememberInt(Context context, int feature, int value) {
        if (context == null) return;
        SharedPreferences.Editor edit = store(context).edit();
        if (feature == 13) {
            value = Math.max(0, Math.min(3, value));
            edit.putBoolean("enabled", value > 0);
            if (value > 0) edit.putInt("last_mode", value);
        } else if (feature >= 14 && feature <= 16) {
            int low = feature == 15 ? 5 : feature == 14 ? 1 : 0;
            int high = feature == 15 ? 100 : feature == 14 ? 5 : 2;
            edit.putInt("feature_" + feature, Math.max(low, Math.min(high, value)));
        }
        edit.apply();
    }

    static void rememberBool(Context context, int feature, boolean value) {
        if (context != null && feature == 17) store(context).edit().putBoolean("cushion", value).apply();
    }

    static int savedInt(Context context, int feature) {
        if (context == null) return 0;
        SharedPreferences prefs = store(context);
        switch (feature) {
            case 13: return prefs.contains("enabled") ? (prefs.getBoolean("enabled", false) ? lastMode(context) : 0) : 0;
            case 14: return Math.max(1, Math.min(5, prefs.getInt("feature_14", 5)));
            case 15: return Math.max(5, Math.min(100, prefs.getInt("feature_15", 60)));
            case 16: return Math.max(0, Math.min(2, prefs.getInt("feature_16", 0)));
            default: return 0;
        }
    }

    static boolean savedBool(Context context, int feature, boolean fallback) {
        return context != null && feature == 17 ? store(context).getBoolean("cushion", fallback) : fallback;
    }

    static void restore(Context context) {
        int apMode = savedInt(context, 13);
        for (int feature : new int[]{14, 15, 16}) {
            Preferences.Changes(context, feature, "Autoplay setting", savedInt(context, feature), false, null);
        }
        Preferences.Changes(context, 17, "Cushion Shots Only", 0, savedBool(context, 17, false), null);
        Preferences.Changes(context, 13, "Autoplay", apMode, false, null);
    }
}
